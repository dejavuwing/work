﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server
{
    class FormTest
    {
        public static void Initialize()
        {
            Container.Register("/form.sws", new RequestHandler(FormTest_OnRequest));
        }

        public static void FormTest_OnRequest(Request req, out Response resp)
        {
            resp = new Response(200);
            resp.ContentType = "text/html";
            resp.CharacterSet = "UTF-8";

            StringBuilder contents = new StringBuilder();

            contents.Append("<html>" + "\r\n");
            contents.Append("    <head>" + "\r\n");
            contents.Append("        <title>Form 테스트 result</title>" + "\r\n");
            contents.Append("    </head>" + "\r\n");
            contents.Append("    <body>" + "\r\n");
            contents.Append("        <center>" + "\r\n");
            contents.Append("            <h1>This is FORM TEST SCRIPT!!</h1>");
            contents.Append("            <h3>" + DateTime.Now.ToString("r") + "</h3>" + "\r\n");
            contents.Append("            <h3>Hidden: \"<i>" + req.Posts("hidden_item") + "</i>\"</h3>" + "\r\n");
            contents.Append("            <h3>Textbox: \"<i>" + req.Posts("text_item") + "</i>\"</h3>" + "\r\n");
            contents.Append("            <h3>Password: \"<i>" + req.Posts("pass_item") + "</i>\"</h3>" + "\r\n");
            contents.Append("            <h3>Textarea: \"<i>" + req.Posts("area_item") + "</i>\"</h3>" + "\r\n");
            contents.Append("            <h3>File: \"<i>" + req.Posts("file_item") + "</i>\"</h3>" + "\r\n");
            contents.Append("        <center>" + "\r\n");
            contents.Append("    </body>" + "\r\n");
            contents.Append("</html>" + "\r\n");

            resp.Contents = Encoding.UTF8.GetBytes(contents.ToString());
        }
    }
}

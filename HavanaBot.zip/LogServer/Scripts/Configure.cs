﻿using System;
using System.Collections.Generic;
using System.Text;

using System.IO;
using System.Reflection;

namespace Server
{
    public class Configure
    {
        public static void Initialize()
        {
            Console.WriteLine();
            //Console.Write("Configuring server...");

            #region Server environments
            Core.ServerName = "Havana Bot Server";
            Core.DocumentRoot = Directory.GetParent(Environment.CurrentDirectory).Parent.FullName + "\\wwwroot";
            Core.ServerPort = 9999;
            Core.RequestTimeOut = 500;
            Core.Indexes = new string[] { "bot_log.html" };
            #endregion

            #region Define mime types
            //MimeType.DefaultCharSet = "UTF-8";
            //MimeType.DefaultType = "application/octet-stream";
            //MimeType.Add(".html", "text/html");
            MimeType.AddRange(new string[] { ".html", ".htm", ".sws" }, "text/html");
            MimeType.Add(".gif", "image/gif");
            MimeType.AddRange(new string[] { ".jpg", ".jpeg" }, "image/jpeg");
            MimeType.Add(".png", "image/png");
            MimeType.Add(".ico", "image/vnd.microsoft.icon");
            #endregion

            #region Define response codes
            Response.Add(200, "OK");
            Response.Add(404, "Not Found");
            Response.Add(500, "Internal Server Error");
            Response.Add(501, "Not Implemented");
            #endregion

            //Console.WriteLine(" done");
            Console.WriteLine("{0}", Core.ServerName);
            //Console.WriteLine("Env] Root: {0}", Core.DocumentRoot);
            //Console.WriteLine("Env] Timeout: {0}ms", Core.RequestTimeOut);
        }

    }
}
